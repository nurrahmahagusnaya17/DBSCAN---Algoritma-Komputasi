# Implementasi DBSCAN dari Nol — Pelanggan Toko

## Kepatuhan slide 9–10
- **Inti DBSCAN ditulis sendiri** pada `dbscan_dari_nol` serta `tetangga_epsilon`: tidak memanggil `sklearn.cluster.DBSCAN` untuk membentuk klaster utama.
- **scikit-learn hanya pembanding** (partisi/ARI dan waktu eksekusi).
- **3 kasus uji manual** dari sheet `Uji_1_Satu_Cluster`, `Uji_2_Dua_Cluster`, dan `Uji_3_Cluster_Noise` (ε=1.5, MinPts=3).
- **5 ukuran input**, masing-masing **5 kali pengulangan**, rata-rata dan simpangan baku.
- **Sensitivitas ε dan MinPts** masing-masing tiga nilai; grafik waktu terhadap n dan kurva referensi O(n²).

## Data
CSV pada folder `data/` merupakan hasil ekstraksi tanpa mengubah nilai dari file Excel `Paket_Dataset_DBSCAN_Pelanggan_Toko(2).xlsx` milik mahasiswa. **Sheet `Dataset_1600` ternyata hanya memiliki 400 data pelanggan valid**, bukan 1.600. Pengujian dilakukan untuk 25, 50, 100, 200, dan 400 data. Data bersifat simulasi.

Fitur yang digunakan: frekuensi belanja bulanan dan rata-rata nilai transaksi. Kedua fitur dinormalisasi dengan Z-score (rata-rata dan simpangan baku dihitung secara manual). Kolom total pengeluaran tidak dijadikan fitur karena merupakan produk dari dua atribut tadi.

## Instalasi dan menjalankan
```bash
python -m pip install -r requirements.txt
python eksperimen_dbscan.py
```
Dijalankan dari terminal di folder proyek. Skrip memuat data dengan path relatif terhadap skrip, sehingga tidak memerlukan file lokal `/mnt/data`.

## Contoh keluaran
```
=== 3 KASUS UJI MANUAL ===
... ARI=1.000 ...
=== DATA PELANGGAN ===
Jumlah data aktual: 400; fitur=2
...
Semua pengujian selesai. Periksa folder hasil/.
```

## Hasil yang dibuat otomatis
- `hasil/hasil_uji_manual.csv`: hasil tiga kasus kecil.
- `hasil/label_pelanggan.csv`, `ringkasan_klaster.csv`: label dan jumlah pelanggan tiap klaster.
- `hasil/hasil_waktu.csv`: rata-rata dan simpangan baku waktu (ms).
- `hasil/hasil_sensitivitas.csv`: sensitivitas ε dan MinPts.
- `hasil/grafik_klaster.png` dan `grafik_waktu.png`.

## Catatan metodologis
1. MinPts **termasuk titik itu sendiri**, sesuai konvensi DBSCAN.
2. Titik yang mula-mula noise boleh berubah menjadi border point bila dapat dijangkau dari core point.
3. Perbandingan klaster memakai ARI karena nomor label klaster boleh berbeda sementara partisinya sama. Ambiguitas border point dalam dataset tertentu dapat menyebabkan perbedaan assignment walaupun kedua implementasi DBSCAN valid.
4. Waktu diukur hanya saat pemanggilan algoritma, bukan pembacaan CSV, standardisasi, atau penyimpanan plot.
5. Standarisasi dataset lengkap dilakukan sebelum sampling untuk eksperimen ukuran input. Laporkan keputusan ini di BAB IV.
6. Grafik teoretis O(n²) merupakan **kurva referensi yang diskalakan**, bukan hasil pengukuran.
7. Jalankan ulang pada perangkat yang akan dilaporkan di BAB IV agar angka waktu konsisten dengan spesifikasi komputer.
8. Penggunaan AI untuk bantuan penulisan/debugging dilaporkan sesuai ketentuan integritas akademik. Pahami dan verifikasi setiap fungsi serta interpretasi hasil secara mandiri.
